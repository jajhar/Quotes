//
//  UsernameTags.swift
//  Quotes
//
//  Created by James Ajhar on 9/7/16.
//  Copyright © 2016 James Ajhar. All rights reserved.
//

import Foundation
import CoreData


class UsernameTags: NSManagedObject {

// Insert code here to add functionality to your managed object subclass

}
